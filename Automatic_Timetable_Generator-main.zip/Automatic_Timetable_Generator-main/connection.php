<?php
$con = mysqli_connect("localhost", "root", "", "lamp_innovative");
?>